package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import modelo.Estudiante;


public class EstudianteDAO {

	 public void create(Estudiante e) {
	        String sql = "INSERT INTO estudiantes(nombre, correo, carrera) VALUES (?, ?, ?)";
	        try (Connection con = ConexionBD.conectar();
	             PreparedStatement ps = con.prepareStatement(sql)) {
	            ps.setString(1, e.getNombre());
	            ps.setString(2, e.getCorreo());
	            ps.setString(3, e.getCarrera());
	            ps.executeUpdate();
	        } catch (Exception ex) { ex.printStackTrace(); }
	    }

	    public List<Estudiante> readAll() {
	        List<Estudiante> lista = new ArrayList<>();
	        String sql = "SELECT * FROM estudiantes";
	        try (Connection con = ConexionBD.conectar();
	             PreparedStatement ps = con.prepareStatement(sql);
	             ResultSet rs = ps.executeQuery()) {

	            while (rs.next()) {
	                lista.add(new Estudiante(
	                        rs.getInt("id"),
	                        rs.getString("nombre"),
	                        rs.getString("correo"),
	                        rs.getString("carrera")
	                ));
	            }
	        } catch (Exception e) { e.printStackTrace(); }
	        return lista;
	    }

	    public Estudiante readById(int id) {
	        String sql = "SELECT * FROM estudiantes WHERE id = ?";
	        try (Connection con = ConexionBD.conectar();
	             PreparedStatement ps = con.prepareStatement(sql)) {
	            ps.setInt(1, id);
	            ResultSet rs = ps.executeQuery();
	            if (rs.next()) {
	                return new Estudiante(
	                        rs.getInt("id"),
	                        rs.getString("nombre"),
	                        rs.getString("correo"),
	                        rs.getString("carrera")
	                );
	            }
	        } catch (Exception e) { e.printStackTrace(); }
	        return null;
	    }

	    public void update(Estudiante e) {
	        String sql = "UPDATE estudiantes SET nombre=?, correo=?, carrera=? WHERE id=?";
	        try (Connection con = ConexionBD.conectar();
	             PreparedStatement ps = con.prepareStatement(sql)) {

	            ps.setString(1, e.getNombre());
	            ps.setString(2, e.getCorreo());
	            ps.setString(3, e.getCarrera());
	            ps.setInt(4, e.getId());
	            ps.executeUpdate();

	        } catch (Exception ex) { ex.printStackTrace(); }
	    }

	    public void delete(int id) {
	        String sql = "DELETE FROM estudiantes WHERE id=?";
	        try (Connection con = ConexionBD.conectar();
	             PreparedStatement ps = con.prepareStatement(sql)) {

	            ps.setInt(1, id);
	            ps.executeUpdate();

	        } catch (Exception ex) { ex.printStackTrace(); }
	    }
	}