package controlador;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;


import dao.EstudianteDAO;
import modelo.Estudiante;
public class EstudianteServlet extends HttpServlet {

    EstudianteDAO dao = new EstudianteDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String accion = req.getParameter("accion");

        if (accion == null) accion = "listar";

        switch (accion) {
            case "nuevo":
                req.getRequestDispatcher("vista/agregar.jsp").forward(req, resp);
                break;

            case "editar":
                int id = Integer.parseInt(req.getParameter("id"));
                req.setAttribute("est", dao.readById(id));
                req.getRequestDispatcher("vista/editar.jsp").forward(req, resp);
                break;

            case "eliminar":
                dao.delete(Integer.parseInt(req.getParameter("id")));
                resp.sendRedirect("EstudianteServlet?accion=listar");
                break;

            default: // listar
                req.setAttribute("lista", dao.readAll());
                req.getRequestDispatcher("vista/listar.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String accion = req.getParameter("accion");

        switch (accion) {
            case "guardar":
                Estudiante e = new Estudiante();
                e.setNombre(req.getParameter("nombre"));
                e.setCorreo(req.getParameter("correo"));
                e.setCarrera(req.getParameter("carrera"));
                dao.create(e);
                break;

            case "actualizar":
                Estudiante e2 = new Estudiante();
                e2.setId(Integer.parseInt(req.getParameter("id")));
                e2.setNombre(req.getParameter("nombre"));
                e2.setCorreo(req.getParameter("correo"));
                e2.setCarrera(req.getParameter("carrera"));
                dao.update(e2);
                break;
        }

        resp.sendRedirect("EstudianteServlet?accion=listar");
    }
}